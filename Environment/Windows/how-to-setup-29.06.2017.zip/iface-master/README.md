iface
=====

Rather bad Windows/Linux RPC interface specialized for a Windows-host/Linux-guest configuration.

**WARNING**: The Windows/Linux iface by is EXPERIMENTAL and has nothing to do with good coding, security, etc. **USE AT YOUR OWN RISK**.

Some details on the configuration can be found here:
https://docs.google.com/document/d/1bq3lXdB2G4Mr2xVSxGdx6icleV7bfWbDUQUOuXzftTY/edit?usp=sharing


